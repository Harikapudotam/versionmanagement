sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("ust.so.buyer.controller.App", {
      onInit() {
      }
  });
});